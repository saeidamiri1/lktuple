f0 <- function(vec, fn){
  vec0<-c(vec,c(vec[length(vec)]+1))
  vecs <- mapply(seq, 1, vec0)
  vecs1<-vecs[-length(vecs)]
  tmp <- do.call(expand.grid, vecs1)
  tmp <- apply(tmp, 1, fn)
  (tmp)
}

fn = function(x){paste(c(x), collapse="")}



RECINV<-function (XX,ORG0){
  LL <- NULL
  LL2 <- list()
  z <- 1
  K0<-length(ORG0)
  for (i1 in 1:K0) {
    loc <- gregexpr(pattern =ORG0[i1], XX)[[1]]
    bet <- diff(loc)
    LL2[[z]] <- bet
    z <- z + 1
  }
  LL2
}

RECINV<-cmpfun(RECINV)


kldi<-function (Xx, Yy){
  Y <- Yy
  X <- Xx
  f.a <- ecdf(X)
  f.b <- ecdf(Y)
  x0 <- seq(min(X, Y), max(X, Y), length.out = length(X))
  y0 <- diff(f.a(x0))
  y1 <- diff(f.b(x0))
  yy <- y0 * log(y0/y1)
  sum(yy[is.finite(yy)])
}

diffkl<-function (X, Y){
  if (length(X) <= 2 & length(Y) <= 2)
    XYX <- 0
  if (length(X) > 2 & length(Y) <= 2)
    XYX <- NA
  if (length(X) <= 2 & length(Y) > 2)
    XYX <- NA
  if (length(X) > 2 & length(Y) > 2)
    XYX <- kldi(X, Y)
  return(XYX)
}

DistSeqkl<-function(x0,y0){
  xy <- NULL
  for (i in 1:length(x0)) {
    xy[i] <- diffkl(x0[[i]], y0[[i]])
  }
  mmx <- min(is.finite(xy))
  xy[is.na(xy)] <- mmx
  mean(abs(xy))
}


DKLd<-function(XDAT,K){
  ORG0<-f0(c(rep(4, K)), fn = fn)
  Se<-matrix(,ncol=length(XDAT),nrow=length(XDAT))
  XT<-list()
  o<-length(XDAT)
  XT<-list()
  for(i in 1:o){
    XT[[i]]<-RECINV(XDAT[[i]],ORG0)
  }

  for(i in 1:(o-1)){
    XX<-XT[[i]]
    for(j in (i+1):o){
      YY<-XT[[j]]
      Se[i,j]<-DistSeqkl(XX,YY)
    }
  }
  return(Se)
}




