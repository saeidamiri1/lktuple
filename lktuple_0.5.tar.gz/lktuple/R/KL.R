f0 <- function(vec, fn){
  vec0<-c(vec,c(vec[length(vec)]+1))
  vecs <- mapply(seq, 1, vec0)
  vecs1<-vecs[-length(vecs)]
  tmp <- do.call(expand.grid, vecs1)
  tmp <- apply(tmp, 1, fn)
  (tmp)
}

fn = function(x){paste(c(x), collapse="")}



RECINV<-function (XX,ORG0){
  LL <- NULL
  LL2 <- list()
  z <- 1
  K0<-length(ORG0)
  for (i1 in 1:K0) {
    loc <- gregexpr(pattern =ORG0[i1], XX)[[1]]
    bet <- diff(loc)
    LL2[[z]] <- bet
    z <- z + 1
  }
  LL2
}

RECINV<-cmpfun(RECINV)


kldi<-function (Xx, Yy){
  Y <- Yy
  X <- Xx
  f.a <- ecdf(X)
  f.b <- ecdf(Y)
  x0 <- seq(min(X, Y), max(X, Y), length.out = length(X))
  y0 <- diff(f.a(x0))
  y1 <- diff(f.b(x0))
  yy <- y0 * log(y0/y1)
  sum(yy[is.finite(yy)])
}

diffkl<-function (X, Y){
  if (length(X) <= 2 & length(Y) <= 2)
    XYX <- 0
  if (length(X) > 2 & length(Y) <= 2)
    XYX <- NA
  if (length(X) <= 2 & length(Y) > 2)
    XYX <- NA
  if (length(X) > 2 & length(Y) > 2)
    XYX <- kldi(X, Y)
  return(XYX)
}

DistSeqkl<-function(x0,y0){
  xy <- NULL
  for (i in 1:length(x0)) {
    xy[i] <- diffkl(x0[[i]], y0[[i]])
  }
  mmx <- min(is.finite(xy))
  xy[is.na(xy)] <- mmx
  mean(abs(xy))
}



DKLd0<-function(XDAT,K){
  ORG0<-f0(c(rep(4, K)), fn = fn)
  Se<-matrix(,ncol=length(XDAT),nrow=length(XDAT))
  XT<-list()
  o<-length(XDAT)
  XT<-list()
  for(i in 1:o){
    XT[[i]]<-RECINV(XDAT[[i]],ORG0)
  }

  for(i in 1:(o-1)){
    XX<-XT[[i]]
    for(j in (i+1):o){
      YY<-XT[[j]]
      Se[i,j]<-DistSeqkl(XX,YY)
    }
  }
  return(Se)
}





#library(foreach)
#library(doParallel)


DKLdP<-function(XDAT,K,Ncore){
  ORG0<-f0(c(rep(4, K)), fn = fn)
  Se<-matrix(,ncol=length(XDAT),nrow=length(XDAT))
  XT<-list()
  o<-length(XDAT)
  XT<-list()

#  strt<-Sys.time()
  cl<-makeCluster(Ncore)
  clusterExport(cl, "ORG0")
  clusterExport(cl, "XDAT")
  clusterExport(cl, "RECINV")
  clusterExport(cl,"DistSeqkl")
  clusterExport(cl,"diffkl")
  clusterExport(cl,"kldi")

  registerDoParallel(cl)
  XT<-parLapply(cl, 1:o, function(exponent) RECINV(XDAT[[exponent]],ORG0))

  registerDoParallel(cl)
  xx <-
    foreach(j = (1:(o-1)), .combine='cbind') %do% {
      foreach(i = ((j+1):o), .combine = c) %dopar% {
        #  paste(j, i, sep = "")
        obj <- DistSeqkl(XT[[j]],XT[[i]])
        data.frame(x=obj)
      }
    }

  aa<-1
  for(i in 1:(o-1)){
    for(j in (i+1):o){
      Se[i,j]<-c(xx[aa]$x)
      aa<-aa+1
    }
  }
  stopCluster(cl)

 # print(Sys.time()-strt)

  return(Se)
}




#############
DKLd<-function(XDAT,K, Ncore=NULL){
  if(is.null(Ncore)){return(DKLd0(XDAT,K))}
  else{return(DKLdP(XDAT,K,Ncore))}

}

